1. unzip
2. place in maps folder
3. test
4. opinions on fpsbanana please!